export function AppTitle(props) {
  console.log("rendered title");
  return <p>Total topics:{props.topicsCount}</p>;
}
