export function Boy(props) {
  return <b>😁</b>;
}

export function Lover(props) {
  return <b>😍</b>;
}

export default { B: Boy, L: Lover };
